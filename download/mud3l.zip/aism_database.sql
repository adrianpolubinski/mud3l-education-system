-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 14 Cze 2021, 13:13
-- Wersja serwera: 10.4.14-MariaDB
-- Wersja PHP: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `aism_database`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `author_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `rate` int(11) DEFAULT NULL,
  `accepted` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `course_members`
--

CREATE TABLE `course_members` (
  `id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `accepted` int(11) NOT NULL DEFAULT 0,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `dzialaniowiec`
--

CREATE TABLE `dzialaniowiec` (
  `id` int(11) NOT NULL,
  `lesson_id` int(11) NOT NULL,
  `context` text COLLATE utf8_unicode_ci NOT NULL,
  `link` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `lessons`
--

CREATE TABLE `lessons` (
  `id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `subject` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `lesson_member`
--

CREATE TABLE `lesson_member` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `accept` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `persons`
--

CREATE TABLE `persons` (
  `id` int(11) NOT NULL,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `surname` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `phone_number` varchar(9) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Zrzut danych tabeli `persons`
--

INSERT INTO `persons` (`id`, `name`, `surname`, `phone_number`) VALUES
(1, 'Ryszard', 'Ryba', '123123123'),
(16, 'Adam', 'Matowicz', '123765234'),
(23, 'Jan', 'Kowalski', '123123123');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `pytania`
--

CREATE TABLE `pytania` (
  `id` int(11) NOT NULL,
  `id_testu` int(11) NOT NULL,
  `tresc` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `odpowiedz1` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `odpowiedz2` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `odpowiedz3` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `odpowiedz4` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `prawidlowa` varchar(250) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sluchowiec`
--

CREATE TABLE `sluchowiec` (
  `id` int(11) NOT NULL,
  `lesson_id` int(11) NOT NULL,
  `context` text COLLATE utf8_unicode_ci NOT NULL,
  `link` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `testy`
--

CREATE TABLE `testy` (
  `id` int(11) NOT NULL,
  `nazwa` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `opis` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `id_kursu` int(11) NOT NULL,
  `id_lekcji` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `types_of_learn`
--

CREATE TABLE `types_of_learn` (
  `id` int(11) NOT NULL,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Zrzut danych tabeli `types_of_learn`
--

INSERT INTO `types_of_learn` (`id`, `name`, `description`) VALUES
(1, 'słuchowiec', ''),
(2, 'wzrokowiec', ''),
(3, 'działaniowiec', '');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `person_id` int(4) NOT NULL,
  `account_type` int(4) NOT NULL,
  `type_of_learn` int(11) DEFAULT NULL,
  `create_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Zrzut danych tabeli `users`
--

INSERT INTO `users` (`id`, `login`, `password`, `email`, `person_id`, `account_type`, `type_of_learn`, `create_date`) VALUES
(1, 'admin', '$2y$10$QC/eXt1NXfIE3gHKsPWLUOIGZkCbSoaAFVXQj3zHv1zgIjWvgQ0gW', 'admin@mudel.pl', 1, 1, 1, '2021-03-18'),
(8, 'nauczyciel', '$2y$10$qDae0iOtxBrChq/JSyFRx..GcMhkAM9yZQbsbXNNFXDCDrBh6/JBy', 'nauczyciel@mudel.pl', 16, 2, 2, '2021-05-04'),
(15, 'kursant', '$2y$10$dBabdchAi1EklfEVKpZVpOSlkyo0eVvs6WsFyvYKchzRzxoMpqGAe', 'kursant@mudel.pl', 23, 3, 3, '2021-06-01');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `wyniki`
--

CREATE TABLE `wyniki` (
  `id` int(11) NOT NULL,
  `id_testu` int(11) NOT NULL,
  `id_konta` int(11) NOT NULL,
  `wynik` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `zaliczenie` int(1) NOT NULL,
  `data` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `typ_uczenia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `wzrokowiec`
--

CREATE TABLE `wzrokowiec` (
  `id` int(11) NOT NULL,
  `lesson_id` int(11) NOT NULL,
  `context` text COLLATE utf8_unicode_ci NOT NULL,
  `link` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`) USING BTREE;

--
-- Indeksy dla tabeli `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`) USING BTREE,
  ADD KEY `author_idFK` (`author_id`) USING BTREE,
  ADD KEY `category_id` (`category_id`);

--
-- Indeksy dla tabeli `course_members`
--
ALTER TABLE `course_members`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_id` (`course_id`),
  ADD KEY `member_id` (`member_id`);

--
-- Indeksy dla tabeli `dzialaniowiec`
--
ALTER TABLE `dzialaniowiec`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lesson_id` (`lesson_id`);

--
-- Indeksy dla tabeli `lessons`
--
ALTER TABLE `lessons`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_idFK` (`course_id`) USING BTREE;

--
-- Indeksy dla tabeli `lesson_member`
--
ALTER TABLE `lesson_member`
  ADD PRIMARY KEY (`id`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indeksy dla tabeli `persons`
--
ALTER TABLE `persons`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `pytania`
--
ALTER TABLE `pytania`
  ADD PRIMARY KEY (`id`),
  ADD KEY `foreign` (`id_testu`) USING BTREE;

--
-- Indeksy dla tabeli `sluchowiec`
--
ALTER TABLE `sluchowiec`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lesson_idFK` (`lesson_id`) USING BTREE;

--
-- Indeksy dla tabeli `testy`
--
ALTER TABLE `testy`
  ADD PRIMARY KEY (`id`),
  ADD KEY `foreign` (`id_kursu`),
  ADD KEY `id_lekcji` (`id_lekcji`);

--
-- Indeksy dla tabeli `types_of_learn`
--
ALTER TABLE `types_of_learn`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `loginUNIQUE` (`login`) USING BTREE,
  ADD UNIQUE KEY `person_idUNIQUE` (`person_id`) USING BTREE,
  ADD KEY `emailUNIQUE` (`email`) USING BTREE,
  ADD KEY `person_idFK` (`person_id`) USING BTREE,
  ADD KEY `type_of_learnFK` (`type_of_learn`) USING BTREE;

--
-- Indeksy dla tabeli `wyniki`
--
ALTER TABLE `wyniki`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_konta` (`id_konta`),
  ADD KEY `id_testu` (`id_testu`) USING BTREE,
  ADD KEY `typ_uczenia_fk` (`typ_uczenia`);

--
-- Indeksy dla tabeli `wzrokowiec`
--
ALTER TABLE `wzrokowiec`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lesson_idFK` (`lesson_id`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT dla tabeli `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT dla tabeli `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT dla tabeli `course_members`
--
ALTER TABLE `course_members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT dla tabeli `dzialaniowiec`
--
ALTER TABLE `dzialaniowiec`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT dla tabeli `lessons`
--
ALTER TABLE `lessons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT dla tabeli `lesson_member`
--
ALTER TABLE `lesson_member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT dla tabeli `persons`
--
ALTER TABLE `persons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT dla tabeli `pytania`
--
ALTER TABLE `pytania`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT dla tabeli `sluchowiec`
--
ALTER TABLE `sluchowiec`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT dla tabeli `testy`
--
ALTER TABLE `testy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT dla tabeli `types_of_learn`
--
ALTER TABLE `types_of_learn`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT dla tabeli `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT dla tabeli `wyniki`
--
ALTER TABLE `wyniki`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;

--
-- AUTO_INCREMENT dla tabeli `wzrokowiec`
--
ALTER TABLE `wzrokowiec`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Ograniczenia dla zrzutów tabel
--

--
-- Ograniczenia dla tabeli `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `courses_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Ograniczenia dla tabeli `course_members`
--
ALTER TABLE `course_members`
  ADD CONSTRAINT `course_members_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `course_members_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`);

--
-- Ograniczenia dla tabeli `dzialaniowiec`
--
ALTER TABLE `dzialaniowiec`
  ADD CONSTRAINT `dzialaniowiec_ibfk_1` FOREIGN KEY (`lesson_id`) REFERENCES `lessons` (`id`);

--
-- Ograniczenia dla tabeli `lessons`
--
ALTER TABLE `lessons`
  ADD CONSTRAINT `lessons_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`);

--
-- Ograniczenia dla tabeli `lesson_member`
--
ALTER TABLE `lesson_member`
  ADD CONSTRAINT `lesson_member_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `lesson_member_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`);

--
-- Ograniczenia dla tabeli `pytania`
--
ALTER TABLE `pytania`
  ADD CONSTRAINT `Pytania_ibfk_1` FOREIGN KEY (`id_testu`) REFERENCES `testy` (`id`);

--
-- Ograniczenia dla tabeli `sluchowiec`
--
ALTER TABLE `sluchowiec`
  ADD CONSTRAINT `sluchowiec_ibfk_1` FOREIGN KEY (`lesson_id`) REFERENCES `lessons` (`id`);

--
-- Ograniczenia dla tabeli `testy`
--
ALTER TABLE `testy`
  ADD CONSTRAINT `testy_ibfk_1` FOREIGN KEY (`id_kursu`) REFERENCES `courses` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ograniczenia dla tabeli `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`),
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`type_of_learn`) REFERENCES `types_of_learn` (`id`);

--
-- Ograniczenia dla tabeli `wyniki`
--
ALTER TABLE `wyniki`
  ADD CONSTRAINT `wyniki_ibfk_1` FOREIGN KEY (`id_testu`) REFERENCES `testy` (`id`),
  ADD CONSTRAINT `wyniki_ibfk_2` FOREIGN KEY (`id_konta`) REFERENCES `users` (`id`);

--
-- Ograniczenia dla tabeli `wzrokowiec`
--
ALTER TABLE `wzrokowiec`
  ADD CONSTRAINT `wzrokowiec_ibfk_1` FOREIGN KEY (`lesson_id`) REFERENCES `lessons` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
