<?php
$host = "localhost";
$db_login = "root";
$db_pass = "";
$db_name = "mud3l";
